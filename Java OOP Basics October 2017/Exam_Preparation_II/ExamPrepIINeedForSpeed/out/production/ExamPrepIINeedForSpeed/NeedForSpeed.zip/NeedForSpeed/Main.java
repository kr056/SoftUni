package NeedForSpeed;

import NeedForSpeed.IO.InputReader;
import NeedForSpeed.IO.OutputWriter;

import java.io.IOException;

/**
 * Created by Bang on 9.11.2017 г..
 */
public class Main {
    public static void main(String[] args) throws IOException {
        InputReader inputReader = new InputReader();
        inputReader.readInfo();

        System.out.print(OutputWriter.getAll());
    }
}
