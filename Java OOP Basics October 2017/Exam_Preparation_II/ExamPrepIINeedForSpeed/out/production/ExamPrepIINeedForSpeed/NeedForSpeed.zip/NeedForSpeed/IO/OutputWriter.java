package NeedForSpeed.IO;



/**
 * Created by Bang on 9.11.2017 г..
 */
public class OutputWriter {
    private static StringBuilder all = new StringBuilder();
    public static void gatherAllForPrint(String info){
        OutputWriter.all.append(info);
    }

    public  static StringBuilder getAll() {
        return all;
    }
}
