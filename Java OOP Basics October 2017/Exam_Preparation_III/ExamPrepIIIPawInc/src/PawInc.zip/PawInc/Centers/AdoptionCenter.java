package PawInc.Centers;

import PawInc.Animals.Dog;

/**
 * Created by Bang on 10.11.2017 г..
 */
public class AdoptionCenter extends Center {
    public AdoptionCenter(String name) {
        super(name);
    }


    @Override
    public String toString() {
        return null;
    }

}
