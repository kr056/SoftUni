package PawInc.Centers;

/**
 * Created by Bang on 11.11.2017 г..
 */
public class CastrationCenter extends Center {
    public CastrationCenter(String name) {
        super(name);
    }

    @Override
    public String toString() {
        return null;
    }
}
