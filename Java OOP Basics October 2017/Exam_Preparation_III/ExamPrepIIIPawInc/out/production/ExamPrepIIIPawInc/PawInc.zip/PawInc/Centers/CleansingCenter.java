package PawInc.Centers;

/**
 * Created by Bang on 10.11.2017 г..
 */
public class CleansingCenter extends Center {

    public CleansingCenter(String name) {
        super(name);
    }

    @Override
    public String toString() {
        return null;
    }



}
